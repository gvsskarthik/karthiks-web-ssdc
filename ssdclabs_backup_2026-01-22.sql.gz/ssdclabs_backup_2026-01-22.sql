-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: ssdclabs
-- ------------------------------------------------------
-- Server version	8.0.44-0ubuntu0.22.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `doctors`
--

DROP TABLE IF EXISTS `doctors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doctors` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `hospital` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `specialization` varchar(255) DEFAULT NULL,
  `commission_rate` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctors`
--

LOCK TABLES `doctors` WRITE;
/*!40000 ALTER TABLE `doctors` DISABLE KEYS */;
INSERT INTO `doctors` VALUES (1,'ssdc','G V S S KARTHIK','+917702435637','M B B S',60),(2,'SSDC','SELF','+919505352880','SELF',NULL);
/*!40000 ALTER TABLE `doctors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `normal_ranges`
--

DROP TABLE IF EXISTS `normal_ranges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `normal_ranges` (
  `max_value` double DEFAULT NULL,
  `min_value` double DEFAULT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `parameter_id` bigint NOT NULL,
  `text_value` text,
  `gender` enum('ANY','FEMALE','MALE') NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKktojuj9ly00rpxgynwqxgelnv` (`parameter_id`),
  CONSTRAINT `FKktojuj9ly00rpxgynwqxgelnv` FOREIGN KEY (`parameter_id`) REFERENCES `test_parameters` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `normal_ranges`
--

LOCK TABLES `normal_ranges` WRITE;
/*!40000 ALTER TABLE `normal_ranges` DISABLE KEYS */;
INSERT INTO `normal_ranges` VALUES (NULL,NULL,3,2,'[ Male      : 14.0  - 16.0  gms ]','ANY'),(NULL,NULL,4,2,'[ Female  : 12.0  -  15.0 gms ]','ANY'),(NULL,NULL,5,3,'[ 4,000 – 10,000 cells/cumm ]','ANY'),(NULL,NULL,6,4,'[ 40 – 70 % ]','ANY'),(NULL,NULL,7,5,'[ 20 – 40 % ]','ANY'),(NULL,NULL,8,6,'[ 02 – 06 % ]','ANY'),(NULL,NULL,9,7,'[ 05 – 15 mm ]','ANY'),(NULL,NULL,10,8,'[ 3.8 – 5.8  millions/cumm ]','ANY'),(NULL,NULL,11,9,'[ 1.5 -4.0 lakhs/cumm ]','ANY'),(NULL,NULL,16,24,'Non – Diabetic  : 70 – 110 mg/dl','ANY'),(NULL,NULL,17,24,'Intolerance :  111 – 126 mg/dl','ANY'),(NULL,NULL,18,24,'Diabetic  : > 126 mg/dl','ANY'),(NULL,NULL,19,25,'text','ANY');
/*!40000 ALTER TABLE `normal_ranges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patients` (
  `age` int DEFAULT NULL,
  `amount` double NOT NULL,
  `visit_date` date DEFAULT NULL,
  `doctor_id` bigint DEFAULT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `gender` enum('ANY','FEMALE','MALE') NOT NULL,
  `discount` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKperqpk72jxd90l8yq7qf5fsx0` (`doctor_id`),
  CONSTRAINT `FKperqpk72jxd90l8yq7qf5fsx0` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES (25,100,'2026-01-08',1,2,'TANUKU','9505352880','SWETHA','NOT COMPLETE','MALE',0),(15,100,'2026-01-09',1,3,'TANUKU','7989191823','KARTHIK','NOT COMPLETE','MALE',0),(15,550,'2026-01-22',1,28,'TANUKU','7989191823','KARTHIK','NOT COMPLETE','MALE',0),(15,550,'2026-01-22',1,29,'TANUKU','7989191823','KARTHIK','NOT COMPLETE','MALE',0),(15,550,'2026-01-22',1,30,'TANUKU','7989191823','KARTHIK','NOT COMPLETE','MALE',0),(15,550,'2026-01-22',1,31,'TANUKU','7989191823','KARTHIK','NOT COMPLETE','MALE',0),(15,250,'2026-01-22',1,32,'TANUKU','7989191823','KARTHIK','NOT COMPLETE','MALE',0),(15,150,'2026-01-22',1,33,'TANUKU','7989191823','KARTHIK','NOT COMPLETE','MALE',0),(25,150,'2026-01-22',1,34,'TANUKU','9505352880','SWETHA','NOT COMPLETE','MALE',0),(25,550,'2026-01-22',1,35,'TANUKU','9505352880','SWETHA','NOT COMPLETE','MALE',0),(25,250,'2026-01-22',1,36,'TANUKU','9505352880','SWETHA','NOT COMPLETE','MALE',0),(15,250,'2026-01-22',1,37,'TANUKU','7989191823','KARTHIK','NOT COMPLETE','MALE',0),(25,250,'2026-01-22',1,38,'TANUKU','9505352880','SWETHA','NOT COMPLETE','ANY',0),(15,100,'2026-01-22',1,39,'TANUKU','7989191823','KARTHIK','NOT COMPLETE','MALE',0),(25,100,'2026-01-22',1,40,'TANUKU','9505352880','SWETHA','NOT COMPLETE','ANY',0),(15,100,'2026-01-22',1,41,'TANUKU','7989191823','KARTHIK','NOT COMPLETE','MALE',0);
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report_results`
--

DROP TABLE IF EXISTS `report_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `report_results` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `parameter_id` bigint NOT NULL,
  `patient_id` bigint NOT NULL,
  `test_id` bigint NOT NULL,
  `result_value` text,
  `sub_test` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK3wd5fgi3ly08kck6wwej1x597` (`patient_id`,`test_id`,`parameter_id`),
  UNIQUE KEY `UKlmiu6449acvtdj06i8c5yxgnv` (`patient_id`,`test_id`,`parameter_id`,`sub_test`),
  KEY `FKdt0uoagp4gpl4esyn26xmj7f1` (`parameter_id`),
  KEY `FKgoh2dr8v1kdeomsra5ferqm0i` (`test_id`),
  CONSTRAINT `FKdt0uoagp4gpl4esyn26xmj7f1` FOREIGN KEY (`parameter_id`) REFERENCES `test_parameters` (`id`),
  CONSTRAINT `FKgoh2dr8v1kdeomsra5ferqm0i` FOREIGN KEY (`test_id`) REFERENCES `tests` (`id`),
  CONSTRAINT `FKniwldp5jno418ji1bjf49tusm` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=256 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report_results`
--

LOCK TABLES `report_results` WRITE;
/*!40000 ALTER TABLE `report_results` DISABLE KEYS */;
INSERT INTO `report_results` VALUES (2,2,2,2,'13.0',NULL),(3,2,3,2,'14',NULL),(138,2,28,2,NULL,NULL),(139,3,28,3,NULL,NULL),(140,4,28,5,NULL,NULL),(141,5,28,5,NULL,NULL),(142,6,28,5,NULL,NULL),(143,7,28,6,NULL,NULL),(144,8,28,7,NULL,NULL),(145,9,28,8,NULL,NULL),(146,19,28,10,NULL,NULL),(147,20,28,10,NULL,NULL),(148,21,28,10,NULL,NULL),(149,22,28,10,NULL,NULL),(150,23,28,10,NULL,NULL),(152,2,29,2,NULL,NULL),(153,3,29,3,NULL,NULL),(154,4,29,5,NULL,NULL),(155,5,29,5,NULL,NULL),(156,6,29,5,NULL,NULL),(157,7,29,6,NULL,NULL),(158,8,29,7,NULL,NULL),(159,9,29,8,NULL,NULL),(160,19,29,10,NULL,NULL),(161,20,29,10,NULL,NULL),(162,21,29,10,NULL,NULL),(163,22,29,10,NULL,NULL),(164,23,29,10,NULL,NULL),(166,2,30,2,NULL,NULL),(167,3,30,3,NULL,NULL),(168,4,30,5,NULL,NULL),(169,5,30,5,NULL,NULL),(170,6,30,5,NULL,NULL),(171,7,30,6,NULL,NULL),(172,8,30,7,NULL,NULL),(173,9,30,8,NULL,NULL),(174,19,30,10,NULL,NULL),(175,20,30,10,NULL,NULL),(176,21,30,10,NULL,NULL),(177,22,30,10,NULL,NULL),(178,23,30,10,NULL,NULL),(180,2,31,2,NULL,NULL),(181,3,31,3,NULL,NULL),(182,4,31,5,NULL,NULL),(183,5,31,5,NULL,NULL),(184,6,31,5,NULL,NULL),(185,7,31,6,NULL,NULL),(186,8,31,7,NULL,NULL),(187,9,31,8,NULL,NULL),(188,19,31,10,'TRACES',NULL),(189,20,31,10,'NIL',NULL),(190,21,31,10,'NEGATIVE',NULL),(191,22,31,10,'NEGATIVE',NULL),(192,23,31,10,'PUS CELLS  3 – 5 / hpf',NULL),(195,2,32,2,NULL,NULL),(196,19,32,10,'TRACES',NULL),(197,20,32,10,'NIL',NULL),(198,21,32,10,'NEGATIVE',NULL),(199,22,32,10,'NEGATIVE',NULL),(200,23,32,10,'PUS CELLS  3 – 5 / hpf',NULL),(203,19,33,10,'TRACES',NULL),(204,20,33,10,'NIL',NULL),(205,21,33,10,'NEGATIVE',NULL),(206,22,33,10,'NEGATIVE',NULL),(207,23,33,10,'PUS CELLS  3 – 5 / hpf',NULL),(209,19,34,10,'TRACES',NULL),(210,20,34,10,'NIL',NULL),(211,21,34,10,'NEGATIVE',NULL),(212,22,34,10,'NEGATIVE',NULL),(213,23,34,10,'PUS CELLS  3 – 5 / hpf',NULL),(216,2,35,2,NULL,NULL),(217,3,35,3,NULL,NULL),(218,4,35,5,NULL,NULL),(219,5,35,5,NULL,NULL),(220,6,35,5,NULL,NULL),(221,7,35,6,NULL,NULL),(222,8,35,7,NULL,NULL),(223,9,35,8,NULL,NULL),(224,19,35,10,'TRACES',NULL),(225,20,35,10,'NIL',NULL),(226,21,35,10,'NEGATIVE',NULL),(227,22,35,10,'NEGATIVE',NULL),(228,23,35,10,'PUS CELLS  3 – 5 / hpf',NULL),(232,2,36,2,NULL,NULL),(233,19,36,10,'TRACES',NULL),(234,20,36,10,'NIL',NULL),(235,21,36,10,'NEGATIVE',NULL),(236,22,36,10,'NEGATIVE',NULL),(237,23,36,10,'PUS CELLS  3 – 5 / hpf',NULL),(239,2,37,2,NULL,NULL),(240,19,37,10,'TRACES',NULL),(241,20,37,10,'NIL',NULL),(242,21,37,10,'NEGATIVE',NULL),(243,22,37,10,'NEGATIVE',NULL),(244,23,37,10,'PUS CELLS  3 – 5 / hpf',NULL),(246,2,38,2,NULL,NULL),(247,19,38,10,'TRACES',NULL),(248,20,38,10,'NIL',NULL),(249,21,38,10,'NEGATIVE',NULL),(250,22,38,10,'NEGATIVE',NULL),(251,23,38,10,'PUS CELLS  3 – 5 / hpf',NULL),(253,25,39,12,'text',NULL),(254,25,40,12,'text',NULL),(255,25,41,12,'text',NULL);
/*!40000 ALTER TABLE `report_results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_group_mappings`
--

DROP TABLE IF EXISTS `test_group_mappings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_group_mappings` (
  `display_order` int NOT NULL,
  `group_id` bigint NOT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `test_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK12sylkp9qglbg640t1fuvmsk7` (`group_id`,`test_id`),
  KEY `FK2ijn2pfoh4m0u4lcexnysw0vh` (`test_id`),
  CONSTRAINT `FK2ijn2pfoh4m0u4lcexnysw0vh` FOREIGN KEY (`test_id`) REFERENCES `tests` (`id`),
  CONSTRAINT `FKb46b3ys7qhse4r1sgrloo9d03` FOREIGN KEY (`group_id`) REFERENCES `test_groups` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_group_mappings`
--

LOCK TABLES `test_group_mappings` WRITE;
/*!40000 ALTER TABLE `test_group_mappings` DISABLE KEYS */;
INSERT INTO `test_group_mappings` VALUES (0,1,1,2),(1,1,2,3),(2,1,3,5),(3,1,4,6),(4,1,5,7),(5,1,6,8);
/*!40000 ALTER TABLE `test_group_mappings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_groups`
--

DROP TABLE IF EXISTS `test_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_groups` (
  `active` bit(1) NOT NULL,
  `display_order` int NOT NULL,
  `group_price` double NOT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_name` varchar(255) NOT NULL,
  `shortcut` varchar(255) NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKsb76k7nydhyx3ndveoqak3pcb` (`shortcut`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_groups`
--

LOCK TABLES `test_groups` WRITE;
/*!40000 ALTER TABLE `test_groups` DISABLE KEYS */;
INSERT INTO `test_groups` VALUES (_binary '',0,400,1,'COMPLETE BLOOT PICTURE','CBP',NULL);
/*!40000 ALTER TABLE `test_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `test_parameters`
--

DROP TABLE IF EXISTS `test_parameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `test_parameters` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `test_id` bigint NOT NULL,
  `parameter_name` varchar(255) NOT NULL,
  `unit` varchar(255) DEFAULT NULL,
  `value_type` enum('NUMBER','TEXT') NOT NULL,
  `default_result` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKjy0iog7je9vc05o1iars4vvga` (`test_id`),
  CONSTRAINT `FKjy0iog7je9vc05o1iars4vvga` FOREIGN KEY (`test_id`) REFERENCES `tests` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `test_parameters`
--

LOCK TABLES `test_parameters` WRITE;
/*!40000 ALTER TABLE `test_parameters` DISABLE KEYS */;
INSERT INTO `test_parameters` VALUES (2,2,'HAEMOGLOBIN','gms','NUMBER',NULL),(3,3,'TOTAL COUNT','Cells / cumm','NUMBER',NULL),(4,5,'Polymorphs','%','NUMBER',NULL),(5,5,'Lymphocyte','%','NUMBER',NULL),(6,5,'Eosinophils','%','NUMBER',NULL),(7,6,'E.S.R.','mm /  1 hour','NUMBER',NULL),(8,7,'TOTAL R B C','millions/cumm','NUMBER',NULL),(9,8,'PLATELETS COUNT','lakhs /cumm','NUMBER',NULL),(19,10,'ALBUMIN',NULL,'TEXT','TRACES'),(20,10,'SUGAR',NULL,'TEXT','NIL'),(21,10,'BILE SALTS',NULL,'TEXT','NEGATIVE'),(22,10,'BILE PIGMENTS',NULL,'TEXT','NEGATIVE'),(23,10,'MICRO',NULL,'TEXT','PUS CELLS  3 – 5 / hpf\nRBC  -  NIL\nEPTHELIAL CELLS 4 – 6  / hpf\nCASTS  -  NIL\nCRYSTALS -  NIL'),(24,11,'FASTING BLOOD SUGAR','mg/dl','NUMBER',NULL),(25,12,'Parameter 1','uu','TEXT','text');
/*!40000 ALTER TABLE `test_parameters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tests`
--

DROP TABLE IF EXISTS `tests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tests` (
  `active` bit(1) NOT NULL,
  `cost` double NOT NULL,
  `display_order` int NOT NULL,
  `id` bigint NOT NULL AUTO_INCREMENT,
  `category` varchar(255) DEFAULT NULL,
  `test_name` varchar(255) NOT NULL,
  `test_shortcut` varchar(255) NOT NULL,
  `test_type` enum('MULTI','QUALITATIVE','SINGLE') NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK6t66wm9nskdv4ik79kr0huq9h` (`test_shortcut`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tests`
--

LOCK TABLES `tests` WRITE;
/*!40000 ALTER TABLE `tests` DISABLE KEYS */;
INSERT INTO `tests` VALUES (_binary '',100,0,2,'Hematology','HAEMOGLOBIN','HB','SINGLE'),(_binary '',100,0,3,'Hematology','TOTAL COUNT','TC','SINGLE'),(_binary '',100,0,5,'Hematology','DIFFERENTIAL COUNT','DC','MULTI'),(_binary '',100,0,6,'Hematology','E.S.R.','ESR','SINGLE'),(_binary '',100,0,7,'Hematology','TOTAL R B C','TRBC','SINGLE'),(_binary '',150,0,8,'Hematology','PLATELETS COUNT','PLC','SINGLE'),(_binary '',150,0,10,'Microbiology','URINE EXAMINATION','CUE','MULTI'),(_binary '',50,0,11,'Biochemistry','FASTING BLOOD SUGAR','FBS','SINGLE'),(_binary '',100,0,12,'Biochemistry','pp','pp','QUALITATIVE');
/*!40000 ALTER TABLE `tests` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-22 23:20:10
